# Issue #307 security regression review — R21

**Date:** 2026-10-28 UTC  
**Candidate:** RC6 E5 R21, six x86_64 runtime cells passed; exact component CI passed.  
**Review scope:** this note supplements the R20 change review with the R21 diff and the requested official Podman research. It does **not** complete the issue's A–L security checklist or qualify #307 for closure.

## R21 product change reviewed

R21's only new product-code change was `admirald` commit `04ec1dd7d5de87906e7560194e94fa4afe087354`, in `internal/api/handlers_secrets.go`, with a focused test in `internal/api/setup_flow_test.go`. It recognizes Listmonk's nested `LISTMONK_db__user` and `LISTMONK_db__password` keys and propagates the same instance's database service credentials to those declared app secret keys.

The change does not alter customer authorization, task authentication or claims, privilege boundaries, shell execution, generated Quadlet settings, SELinux, firewall, or secret storage. It extends the existing per-instance database-credential normalization to two additional key names. The exact R21 Listmonk end-to-end run reached `running/healthy/available`, connected to PostgreSQL, passed backup/restore with checksum verification, and cleaned up. R21 component CI passed for the selected source SHAs. No security regression was identified in this change.

## Official Podman `UserNS=auto` research

Reviewed the current official [rootless mode documentation](https://docs.podman.io/en/latest/markdown/podman.1.html#rootless-mode), [container `--userns` documentation](https://docs.podman.io/en/latest/markdown/podman-create.1.html#--userns-mode), [pod `--userns` documentation](https://docs.podman.io/en/stable/markdown/podman-pod-create.1.html#--userns-mode), [Quadlet `[Pod] UserNS=` documentation](https://docs.podman.io/en/latest/markdown/podman-systemd.unit.5.html#pod-unit-options), and [volume ownership documentation](https://docs.podman.io/en/latest/markdown/podman-create.1.html#chowning-volume-mounts).

- Rootless Podman creates a user namespace and needs subordinate UID and GID ranges for the rootless account in `/etc/subuid` and `/etc/subgid`. Admiral's rootless `admiral-apps` account would use those configured ranges.
- In rootless mode, the default mapping maps the caller's host UID to container UID 0. `keep-id` maps it to the same UID in the container; `auto` and `nomap` leave the caller's host UID unmapped.
- `podman pod create --userns=auto` allocates a unique UID/GID range from the configured subordinate pool. The size is estimated unless set explicitly. `[Pod] UserNS=auto` in Quadlet passes this mode to `podman pod create`; every container in the pod shares that pod mapping. A container-level `--userns` is ignored when it joins a pod.
- The ranges are dynamically allocated from one account's pool; they are not fixed per-customer reservations. Rootless `keep-id` or `nomap` without a bounded size can consume the available subordinate ranges and prevent `auto` containers from starting. `--uidmap`, `--gidmap`, `--subuidname`, and `--subgidname` are alternative mapping mechanisms and conflict with `--userns`.
- Container UIDs map to different host IDs under these modes. Podman can adjust ownership on first use of a fresh named volume. `:U` recursively changes host-side ownership and can be slow; `idmap` mounts provide mapped ownership behavior. Existing persistent volumes therefore need explicit compatibility and migration checks. SELinux labels remain a separate control; containers within one pod share its SELinux label.

The existing disposable Rocky Linux prototype used Podman 5.8.2 and two rootless PostgreSQL pods with separate persistent volumes. It observed distinct subordinate UID mappings, persistence across restart, and failure to read a second pod's canary when given its volume path. This was a scoped Podman smoke test, not two Admiral-managed customers. It did not verify MariaDB/MySQL or application images, production user-manager/cgroup behavior, SELinux MCS, Admiral backup/restore, or migration of existing data.

**Recommendation: postpone `UserNS=auto` as optional hardening.** The documented mapping model and prototype show a plausible defense-in-depth improvement for host filesystem DAC, but no demonstrated R21 regression requires it. Broad image, storage lifecycle, backup/restore, and migration compatibility remain unverified; adopting it would expand product scope. This recommendation is not a blocker under the issue's clarification.

## Result and remaining checklist work

The R20 review covered the earlier code changes, and the narrow R21 diff review found no relevant regression in the Listmonk credential propagation. R21's exact-candidate Listmonk E2E and component CI passed. These findings do not establish the controls in the full security checklist.

**Issue #307 remains open.** The existing two-pod Podman prototype is not an Admiral-managed deployment with two customers on one Worker. Checklist evidence is still needed for the applicable A–L controls, especially effective cross-customer filesystem/secret/network isolation, SELinux/MCS and volume ownership, access to the rootless user manager and Podman socket, effective resource limits, current Ansible/network configuration, and lifecycle/backup/restore/deprovision in the relevant deployment. Reuse evidence only where its candidate and effective configuration match; record all uncovered checks as `NOT TESTED`.

The `UserNS=auto` investigation answers only the documentation/prototype portion of section C. Compatibility with Admiral application images, backups/restores, and migration of existing persistent volumes remains unverified. Recommendation remains to postpone adoption as optional hardening; this does not waive the checklist.

`PRODUCT_CHANGED = NO` by this review; it adds evidence only. `CANDIDATE_INVALIDATED = NO`.
