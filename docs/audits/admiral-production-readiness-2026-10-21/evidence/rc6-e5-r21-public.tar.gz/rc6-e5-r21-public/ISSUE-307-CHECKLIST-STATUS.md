# Issue #307 checklist status

**Updated:** 2026-10-28 UTC  
**Candidate evidence reviewed:** R20/R21 runtime records and R21/R22 source reviews.  
**Issue state:** OPEN.  
**Scope:** This tracks only sections A–L in #307. `PARTIAL` means some checks have evidence but the section is not complete. `NOT TESTED` is not a failure and must not be reported as PASS.

R21's 6/6 functional matrix and green CI establish release behavior for their stated tests. They do not establish the full #307 security checklist. The R21 Multi-Node cell used independent Admin, Worker and Portal nodes, but exercised one customer workload, not two customers sharing the Worker.

| Checklist section | Status | Existing evidence | Still required by the checklist |
|---|---|---|---|
| A. Architecture and trust boundaries | PARTIAL | R20/R21 source and service identity review; component boundaries and Fleet's privileged management role are described in the security review. | Trust-boundary diagram; explicit shared/exclusive resource inventory; impact comparison for a compromised workload versus `admiral-apps`. |
| B. Two-customer isolation on one Worker | NOT TESTED | R21 Multi-Node validates one customer workload; the old Podman prototype used two standalone PostgreSQL pods. Neither is two Admiral customers on one Worker. | Two real Admiral customers on one Worker and the listed negative tests for storage, secrets, sockets, pod control, internal services, and resource exhaustion. |
| C. Podman `UserNS=auto` | PARTIAL | Current official docs reviewed; existing two-pod PostgreSQL prototype observed separate mappings, persistence after restart, and a denied read of a second volume's canary. | Admiral-managed workload compatibility for PostgreSQL/MariaDB/MySQL/apps, volume lifecycle, backup/restore/rebuild/update/deprovision, existing-volume migration, capacity, and per-pod range behavior. Adoption is not required; do not implement it as part of this review. |
| D. SELinux and storage isolation | PARTIAL | R21 Single-Node and Multi-Node reports recorded SELinux Enforcing on tested guests. | Effective MCS and volume labels for two customers, cross-customer read/write negatives, AVC review, and persistent enforcement after the relevant reboot on the security test deployment. |
| E. Podman and Quadlet | PARTIAL | R20/R22 source review covers generated unit settings; R21 confirmed rootless Podman on tested workloads. | On the two-customer deployment: effective capabilities, seccomp, SELinux, cgroups/resource limits, process limits, mounts/sockets, generated-file permissions, and behavior under resource pressure. |
| F. systemd user manager | NOT TESTED | Service and unit configuration reviewed statically. | From a customer workload, test visibility/access to the user bus, Podman socket, other units, and cgroups; determine whether a failed unit affects another customer. |
| G. Fleet and privileged operations | PARTIAL | Selected task authentication/ownership paths and R20 migration/storage operations have focused tests and runtime evidence; R21 lifecycle/deprovision passed. | Checklist-directed review and negatives for helper privilege, fallback to rootful Podman, path/symlink handling, forged IDs, cleanup scope, secret exposure, and false success on failure. |
| H. Ansible security baseline | PARTIAL | R21 secure-mode setups and resulting service/firewall/SELinux checks exist for release cells; selected playbook syntax/source checks exist. | Effective/idempotent reapplication checks for the named roles, SSH, auditd, Fail2ban, secret-file permissions, security updates, and `dev-mode` separation. |
| I. Network, WireGuard and exposure | PARTIAL | R21 independent-node setup, authenticated Worker–Portal TLS flow, and peer reconciliation are evidenced. | Effective role-specific IPv4/IPv6 listener and firewall checks, public-IPv6 exposure negatives, revocation and reboot checks for the current security deployment, and inter-workload service access negatives. |
| J. Secrets and backups | PARTIAL | R20 storage task succeeded; R21 single-instance backup/restore checksums and lifecycle passed; selected API ownership tests exist. | Secret canary through logs/arguments/errors/backup, cross-customer secret isolation, storage credential scope, manipulated backup path/object negatives, and two-customer backup/restore ownership. |
| K. Authorization between customers | PARTIAL | Selected API ownership tests and a successful single-customer Portal flow are documented. | Representative live negative requests by customer A against customer B's data, lifecycle and backups on the deployed Multi-Node system; node task-claim and revoked-token checks in the same relevant setup. |
| L. Proportional Multi-Node validation | PARTIAL | R21 passed functional Multi-Node cells using independent Admin, Worker and Portal nodes, with one workload customer's lifecycle, restart/persistence and cleanup. | The section's two customers on one Worker, effective isolation checks, and backup/restore/deprovision coverage for that setup. |

## Current disposition

Section B is `NOT TESTED`, and the two-customer isolation requirement inside L is also `NOT TESTED`: no Admiral-managed two-customer Worker security run is in the evidence. Several other sections are partial; none of these rows is a full-section PASS. The checklist is not complete and #307 must remain open.

The present host has 3.1 GiB available RAM and 46 GiB free disk, with the R18 Admin and Worker VMs running and the Portal VM shut off. No VM was created or started for this update. Do not treat R18 effective runtime evidence as exact R21 evidence. No additional hardening or product modification is proposed by this status report.

`PRODUCT_CHANGED = NO`  
`CANDIDATE_INVALIDATED = NO`
