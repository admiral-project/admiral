# R21 open-issue triage

Checked against the live `admiral-project/admiral` issue tracker on 2026-10-28. The open-issue search returned two issues in this repository.

| Issue | State | R21 status | Remaining work |
|---|---|---|---|
| [#305](https://github.com/admiral-project/admiral/issues/305) — validate example apps definitions | Open | On R21, `e2e-whoami`, Uptime Kuma, Listmonk, Vaultwarden, and WordPress passed lifecycle checks. Cacao Accounting passing is not mandatory per the user's clarification. | ERPNext provisioning did not complete on the latest pinned image, so its lifecycle is unverified. NOW-LMS v1.3.4 failed in its upstream migration; the public Quay registry has no newer image to retry. See [comment 6462156693](https://github.com/admiral-project/admiral/issues/305#issuecomment-6462156693). |
| [#106](https://github.com/admiral-project/admiral/issues/106) — PayPal sandbox E2E alpha gate | Open | Outside this release-validation scope. | PayPal's verified integration is a separate 1.0 gate. It does not block the current six-cell runtime matrix. |

No issue was closed. The R21 release runtime matrix is now 6/6, but R21 is not Gold while GitHub issues remain open. #305 is unresolved; #106 remains open as a separate PayPal 1.0 gate.

## Tracker refresh after R21 review — 2026-10-28 UTC

The R21 candidate itself did not change; this is a documentation-only tracker refresh.

| Issue | Current state | R21 disposition |
|---|---|---|
| [#305](https://github.com/admiral-project/admiral/issues/305) | Closed (`not_planned`) | Closed after the user's direction. This does not turn the incomplete ERPNext and upstream-blocked NOW-LMS runs into PASS evidence. |
| [#307](https://github.com/admiral-project/admiral/issues/307) | Open (`reopened`) | R20/R21 change-focused reviews and `UserNS=auto` research are partial evidence only. The full A–L security checklist was not validated; in particular, two Admiral customers were not exercised on one Worker. |
| [#106](https://github.com/admiral-project/admiral/issues/106) | Open | PayPal sandbox E2E acceptance remains unmet and is separate from the R21 release matrix. |

Issues #255 and #271 are also closed (`completed`). The current live open-issue search returns #307 and #106. R21 remains 6/6 with CI green, but the security checklist and PayPal sandbox acceptance remain open; R21 is not Gold under the project's no-open-issues release rule. No product artifact changed during this review; `CANDIDATE_INVALIDATED = NO`.

The previous closure of #307 was premature: it relied on the change-focused review and the `UserNS=auto` research but did not validate the issue's checklist. #307 was reopened and remains open until the applicable checks are evidenced or explicitly marked `NOT TESTED`.

## Public six-cell evidence tracker — 2026-10-28 UTC

New issue [#308](https://github.com/admiral-project/admiral/issues/308) now centralizes the exact six-cell x86_64 matrix and publishes the R21 candidate identity, CI results, full per-cell reports, and SHA-256 manifests in its comments. R21 remains historical evidence (6/6); the Fleet product change after R21 means its results do not pass the next candidate. The next six-cell matrix is `NOT TESTED` until the Release 23 RPMs are built.
