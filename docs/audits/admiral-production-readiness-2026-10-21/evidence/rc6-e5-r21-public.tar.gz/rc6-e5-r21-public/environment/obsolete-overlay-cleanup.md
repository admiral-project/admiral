# Obsolete CentOS admin overlay cleanup — 2026-10-28

Removed the unused overlay `/var/lib/libvirt/images/admiral-validation/overlays/rc6e5r18-ipv6-admin.qcow2` after verifying:

- No active or shut-off libvirt domain referenced it; the active Admin domain uses `rc6e5r18-ipv6-admin-r21-centos-mn.qcow2`.
- `fuser` reported no process using the file.
- No other qcow2 image had it as a backing file.
- Its backing seed, `CentOS-Stream-10-seed-20261025-rc6-updated.x86_64.qcow2`, remains preserved.
- It was a standalone old overlay with 20 GiB virtual size and 18,369,216,512 bytes allocated.

This is an environment cleanup authorized by the user. It did not change product artifacts, candidate RPMs, or installed VMs.
