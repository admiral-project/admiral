# Rocky Linux 10 x86_64 Single-Node — R21

Date: 2026-10-28 UTC  
Candidate: RC6 E5 R21, Release 21  
Result: **PASS for the Rocky Single-Node release-matrix cell.**

## Candidate and installation

- Reused the existing libvirt domain rc6e5r18-ipv6-admin; no VM or domain was created. The guest booted the updated Rocky Linux 10.2 x86_64 seed using a new copy-on-write overlay. The previous CentOS R21 overlay was preserved.
- Installed all six signed EL10 R21 packages from the local candidate repository. The imported signing-key fingerprint was 8D2E8FC99FB218979157C5DBFCC63E30ED44F66E. Every Admiral RPM reported 5:0.0.1rc6-21.el10.
- admiral-install --single-node --validation-seed completed with exit 0 and Ansible recap ok=233 changed=97 unreachable=0 failed=0.
- The guest reported Rocky Linux 10.2 x86_64, SELinux Enforcing, running firewalld, and 7.0 GiB free before installation. All six required Admiral services were active after setup and after reboot.
- kdump.service and NetworkManager-wait-online.service failed on the updated seed. The latter waited for an IPv6 address on the lab’s link-local-only third interface. The guest remained reachable after boot, and neither failure was Admiral-related.

## Functional checks

All six Single-Node checklist areas passed on the installed R21 candidate:

1. **Workload lifecycle and idempotency:** The first lane invocation supplied rocky-single-r21 as the expected node ID. The clean installer registered the worker as rc6e5r18-ipv6-admin, so the harness stopped before applying a workload. Re-running the same lifecycle check with the registered hostname passed: provision succeeded, same-key replay returned the same operation and instance, PostgreSQL marker was written, HTTP returned 200, deprovision succeeded, and no matching runtime artifacts remained. This was a harness parameter correction, not a product change.
2. **Resize and data continuity:** small → medium → small succeeded. Both transitions preserved the PostgreSQL marker and returned HTTP 200.
3. **Backup and restore:** A database backup completed with checksum ce2a82768e2e8e7a69d620d4b17643c8b6ad81b79dc82aba5575982fe470a8ba. Restore while running was rejected with HTTP 409 as expected. Restore while paused recovered the original marker and HTTP 200. The backup and instance were deleted cleanly.
4. **Instance and control-plane lifecycle:** pause, resume, stop, start, restart, and admirald stop/start recovered to HTTP 200.
5. **Real guest reboot:** boot ID changed from 473fd8ff-c0d0-4d56-a6cd-e1f4013c2024 to 5f0cc55d-d232-4035-a99a-c42d40a8bdad. Workload containers and PostgreSQL recovered, HTTP returned 200, and the r21-reboot-persisted database marker survived. Deprovision succeeded.
6. **Final state:** all six exact R21 EL10 NEVRAs remained installed; PostgreSQL, admirald, Fleet, Caddy, Harbor, and Flagship were active; rootless Podman was enabled; no workload containers, pods, or volumes remained.

## Resource monitoring

Monitoring covered installation, functional runs, and the corrected workload lifecycle. There were no threshold alerts.

- Host minimum available RAM: 4,198,308 KiB (about 4.0 GiB); minimum available disk: 55,433,265,152 bytes (about 51.6 GiB).
- Guest minimum available RAM: 577,740 KiB (about 564 MiB); minimum free disk: 6,534,533,120 bytes (about 6.1 GiB).
- The guest remained above the 256 MiB RAM and 1.5 GiB disk floors; the host remained above the 2 GiB RAM and 30 GiB disk floors. No VM was killed.

## Evidence and release interpretation

- Installer transcript: install.log
- Initial six-stage lane, including the pre-workload node-ID mismatch: functional/rocky-single/lane.log
- Corrected create/idempotency/deprovision check: functional/rocky-single/corrected-workload-create-idempotency-deprovision.log
- Resource samples: resource-monitor.jsonl and functional-resource-monitor.jsonl
- Post-correction package, service, SELinux, rootless runtime, and cleanup check: final-postcheck-corrected.txt
- VM/seed and known-host alias records: reimage-record.txt and known-hosts-alias.txt

The initial lane summary records one failed stage because its node selector did not match the clean installer's registered hostname. That invocation created no workload. The corrected invocation passed the same required check, and all other lane stages passed. This cell is therefore PASS.

No Admiral product artifact changed. PRODUCT_CHANGED=NO and CANDIDATE_INVALIDATED=NO. The R21 runtime matrix is now 3/6. Cacao Accounting passing is not mandatory; issue #305 remains open for other unresolved examples.
