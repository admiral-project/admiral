# Fedora Rawhide x86_64 Single-Node — R21

Date: 2026-10-28 UTC  
Candidate: RC6 E5 R21, Release 21  
Result: **PASS for the Fedora Rawhide Single-Node release-matrix cell.**

## Candidate and installation

- Reused the existing `rc6e5r18-ipv6-admin` domain. No VM or domain was created. The active system was Fedora Linux 46 Cloud Edition Prerelease (Rawhide), x86_64, booted from the updated Fedora seed on a new 10 GiB copy-on-write overlay.
- The prior Rocky and Fedora Admin-role overlays and the original Rocky overlays were preserved. The Admin-role overlay is retained for the Fedora Multi-Node cell.
- All six signed Admiral RPMs were native Fedora `.fc46` builds from the selected R21 source refs. The local Fedora repository SHA-256 manifest passed; installation imported the R21 signing key and installed exactly `5:0.0.1rc6-21.fc46` for all six packages. No EL10 RPM was installed.
- `admiral-install --single-node --validation-seed` completed with exit 0 and Ansible recap `ok=239 changed=99 unreachable=0 failed=0`. It registered healthy, active Worker and Portal roles on the host.
- Fedora reported SELinux Enforcing. All required services were active at final check, no units were failed, `admiralctl status` reported healthy, and rootless Podman 6.1.4 reported `rootless=true`.

## Fedora lab network adjustment

The seed's third NIC was not represented in its NoCloud network config, so NetworkManager generated an automatic DHCP profile for the lab's IPv6-only ULA bridge. That DHCP request timed out and initially caused `NetworkManager-wait-online` to fail. For this lab, the third NIC was assigned `fd76:7665:7269:6679::20/64`, IPv4 was disabled on that NIC, the default route remained on the NAT interface, and the bridge address responded to IPv6 ping. `NetworkManager-wait-online` then became active. This was a VM network-profile adjustment only; no Admiral source or RPM changed. The ULA is a lab address, not public IPv6 evidence.

## Functional checks

All six Fedora Single-Node checklist stages passed:

1. **Workload lifecycle and idempotency:** `e2e-whoami` provisioned on the local Worker, same-key replay returned the same operation and instance, PostgreSQL accepted a marker, and the loopback workload endpoint returned HTTP 200. Deprovision succeeded and left no matching containers, pods, volumes, units, or files.
2. **Resize and data continuity:** small → medium → small succeeded. HTTP returned 200 and the PostgreSQL marker survived both transitions.
3. **Backup and restore:** checksum-verified PostgreSQL backup succeeded. Restore while running was rejected with HTTP 409 as expected; restore while paused recovered the original marker and returned HTTP 200. The backup and instance were deleted cleanly.
4. **Instance and control-plane lifecycle:** pause, resume, stop, start, restart, and `admirald` stop/start recovered successfully; the workload endpoint returned HTTP 200 after recovery.
5. **Real guest reboot:** the boot ID changed from `aef75cfe-5d6c-4939-ae39-84499c171cb6` to `3fd0b81c-c16c-455f-832b-14ef1317d5f1`. The workload recovered to healthy/available, HTTP returned 200, and the `r21-reboot-persisted` PostgreSQL marker survived. Deprovision succeeded.
6. **Final state:** all six exact R21 Fedora NEVRAs remained installed; PostgreSQL, `admirald`, Fleet, Caddy, Harbor, Flagship, firewalld, auditd, fail2ban, and `NetworkManager-wait-online` were active. Rootless Podman had no remaining containers, pods, or volumes. No kernel OOM record was found.

## Resource monitoring

Monitoring covered secure installation and all six functional stages. There were 68 samples and zero threshold alerts.

- Host minimum available RAM: 4,368,624 KiB (about 4.16 GiB); minimum free disk: 49,771,516 KiB (about 47.47 GiB).
- Guest minimum available RAM: 623,932 KiB (about 609 MiB); minimum free disk: 8,421,360 KiB (about 8.03 GiB).
- All samples remained above the host floors of 2 GiB RAM and 30 GiB disk, and guest floors of 256 MiB RAM and 1.5 GiB disk. No VM was killed.

## Evidence and release interpretation

- Secure installer transcript and package verification: `single-node-install.log`.
- Six-stage functional lane: `functional/fedora-single/lane.log`.
- Install and functional resource samples and summary: `single-node-install-resource-monitor.tsv`, `single-node-functional-resource-monitor.tsv`, and `single-node-resource-summary.txt`.
- Final OS, package, service, CLI, node, rootless Podman, resource, and OOM checks: `single-node-final-postcheck.txt`.
- Fedora RPM manifest/checksums: `fedora-rpm-manifest.tsv` and `fedora-rpm-SHA256SUMS`.
- Original Rocky overlays and Fedora VM XML are recorded in this directory; the previous validation overlays remain intact.

No Admiral product artifact changed. `PRODUCT_CHANGED=NO` and `CANDIDATE_INVALIDATED=NO`. The R21 runtime matrix is now **5/6**; Fedora Rawhide Multi-Node remains pending. R21 is not Gold while a required matrix cell is pending and issues remain open. Cacao Accounting passing is not mandatory; issue #305 remains open for ERPNext and NOW-LMS follow-up.
