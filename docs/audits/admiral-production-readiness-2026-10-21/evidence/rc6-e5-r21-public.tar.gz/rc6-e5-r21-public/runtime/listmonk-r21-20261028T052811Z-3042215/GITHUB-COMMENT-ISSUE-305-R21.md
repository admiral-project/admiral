## Listmonk E2E sobre RC6 E5 R21 (2026-10-28)

Actualicé los seis RPM `5:0.0.1rc6-21.el10` sobre la VM CentOS Stream 10 x86_64 Single-Node existente (`rc6e5r18-ipv6-admin`). No creé VMs.

### PASS — lifecycle de Listmonk

- Provision `op_94a3ea193553be10`; instancia `inst_6518df8f3b8d40c7` con `setup_completed=true`, `running`, `healthy` y `available`. El servicio ejecutó Listmonk v6.1.0 y conectó a PostgreSQL con las credenciales generadas.
- Pausa `op_5fab0f090305423b`, reanudación `op_87d962c7778a78a0` y reinicio `op_b49c634602872376` completaron correctamente.
- El endpoint `/health` respondió HTTP 200 tras provisionamiento, reinicio y restore.
- Backup PostgreSQL `bk_abd36a994015883d`, SHA-256 `3d4beb0d14eb7fd84c70662bf1654189899b833c2a302ccdfb1f8f5aa6b65d37`. Cambié un marcador de `original` a `mutated`; restore con verificación de checksum `op_9adeb63e74f18263` lo devolvió a `original`.
- Deprovision `op_0760845f5fa7367c` y borrado del backup `op_38b0529387d55018` completaron correctamente. No quedaron contenedores, Pods, volúmenes ni archivos de workload.

El log de recursos no registró alertas: mínimo de 4.07 GiB RAM y 37.08 GiB disco disponibles en el host; 382 MiB RAM y 11.39 GiB disco en el guest.

### Corrección encontrada en el ejemplo

El primer intento R21 usó `LISTMONK_app__address: 0.0.0.0` y `LISTMONK_app__port` por separado. Listmonk v6.1 espera la dirección completa en `LISTMONK_app__address` y salía con `missing port in address`. Corregí el YAML a `LISTMONK_app__address: "0.0.0.0:9000"` según la [documentación de configuración de Listmonk](https://listmonk.app/docs/configuration/) y repetí el lifecycle. Esto fue un cambio de ejemplo/documentación, no de producto: no reconstruí los RPM y R21 no se invalida por esa corrección.

El fix de producto R21 sí quedó verificado: las claves anidadas `LISTMONK_db__user/password` llegaron a `app` y `setup`; la instancia completó `--install`, alcanzó readiness y el lifecycle pasó.

### Estado de #305

Este comentario registra la validación R21 de Listmonk solamente; no presenta los otros ejemplos como retestados sobre R21. NOW-LMS continúa sin lifecycle completo con la imagen Quay v1.3.4 fijada por digest (la corrida anterior mostró el fallo de migración upstream `relation "curso" does not exist`). Cacao Accounting queda documentado, pero según la aclaración del usuario que pase no es obligatorio.

Dejo #305 abierto mientras NOW-LMS siga pendiente. R21 tampoco es Gold: faltan CI en los SHAs exactos y las seis celdas del runtime matrix.

Reporte y artefactos locales: `docs/audits/admiral-production-readiness-2026-10-21/evidence/rc6-e5-r21/runtime/listmonk-r21-20261028T052811Z-3042215/REPORT.md`.
