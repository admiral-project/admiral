# Listmonk R21 lifecycle validation

Date: 2026-10-28 UTC  
Candidate: RC6 E5 R21  
Guest: existing `rc6e5r18-ipv6-admin`, CentOS Stream 10 x86_64, Single-Node  
Instance: `inst_6518df8f3b8d40c7`

## Result

**PASS** for Listmonk's basic full lifecycle on the six R21 EL10 RPMs. The guest was updated in place; no VM was created. All six installed package NEVRAs are recorded in [`rpm-installed-r21.txt`](rpm-installed-r21.txt).

| Step | Result | Evidence |
|---|---|---|
| Apply and activate updated example | PASS | `apps-apply.log`, `app-activate.log`, `listmonk.yaml` |
| Provision and one-time DB setup | PASS | `provision.json`; `instance-running.json` has `setup_completed=true`, `running`, `healthy`, `available` |
| HTTP health | PASS, 200 | `http-before-lifecycle.txt` |
| Pause and resume | PASS | `pause.json`, `resume.json` |
| Restart | PASS | `restart.json`; `instance-after-restart.json` |
| HTTP after restart | PASS, 200 | `http-after-restart.txt` |
| DB backup | PASS | `backup-db.json`; `backup-id.txt` |
| Checksum-verified DB restore | PASS | `restore-operation.json`, `operations-poll.log` |
| Data persistence | PASS | Marker changed from `original` to `mutated`, then returned to `original`; see `db-marker-read-*.txt` |
| HTTP after restore | PASS, 200 | `http-after-restore.txt` |
| Deprovision and cleanup | PASS | `deprovision.json`, `delete-backup.txt`, `post-cleanup-inventory.txt` |

Backup `bk_abd36a994015883d` SHA-256: `3d4beb0d14eb7fd84c70662bf1654189899b833c2a302ccdfb1f8f5aa6b65d37`. Restore operation `op_9adeb63e74f18263` succeeded with checksum verification. The backup was deleted after the test. The final inventory found no instance containers, pod, or volumes; the backup directory remained empty.

## App-definition correction found during this retest

The first R21 attempt used `LISTMONK_app__address: 0.0.0.0` and a separate `LISTMONK_app__port`. Listmonk v6.1 expects the full `host:port` in `LISTMONK_app__address`, and exited with `listen tcp: address 0.0.0.0: missing port in address`. The example now sets `LISTMONK_app__address: "0.0.0.0:9000"`; Admiral's service `port: 9000` remains the internal container port. The corrected run is this report. The earlier attempt and its cleanup evidence are in the sibling directory `listmonk-r21-20261028T052316Z-3038136/`.

This correction changes only the example YAML and documentation. It did not change an installed Admiral binary or RPM and therefore did not invalidate R21.

## Resource and cleanup record

[`resource-monitor.jsonl`](resource-monitor.jsonl) sampled the host and guest throughout the run, with zero threshold alerts. Minimum available resources were:

- Host: 4.07 GiB RAM and 37.08 GiB disk.
- Guest: 382 MiB RAM and 11.39 GiB disk.

The VM returned to idle after the workload was deprovisioned. The seeds were not changed.
