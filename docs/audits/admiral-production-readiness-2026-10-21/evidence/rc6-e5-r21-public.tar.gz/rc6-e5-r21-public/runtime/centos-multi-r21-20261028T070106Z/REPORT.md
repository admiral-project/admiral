# CentOS Stream 10 x86_64 Multi-Node — R21

Date: 2026-10-28 UTC  
Candidate: RC6 E5 R21, EL10 RPM Release 21  
Result: **PASS for the requested Multi-Node runtime scope.** The public Caddy hostname route was explicitly excluded because no domain points at this lab; Harbor TLS was verified directly over WireGuard with certificate validation enabled.

No product source or RPM changed during this validation. `CANDIDATE_INVALIDATED = NO`. No VM was created or deleted.

## Topology and installed packages

The existing CentOS Stream 10 x86_64 VMs were used as three independent nodes. Each role was installed with its role-specific installer mode.

| Role | VM | WireGuard address | R21 packages installed |
|---|---|---|---|
| Admin | `rc6e5r18-ipv6-admin` | `10.99.0.1` | `admiral-common`, `admirald`, `admiralctl`, `admiral-flagship` |
| Worker | `rc6e5r18-ipv6-worker` | `10.99.0.2` | `admiral-common`, `admiral-fleet` |
| Portal | `rc6e5r18-ipv6-portal` | `10.99.0.100` | `admiral-common`, `admiral-harbor` |

All installed RPMs reported `5:0.0.1rc6-21.el10` in the final node checks. The package SHA-256 values are in the candidate's [`el10/SHA256SUMS`](../../el10/SHA256SUMS) and [`el10/RPM-MANIFEST.tsv`](../../el10/RPM-MANIFEST.tsv).

The Admin install recap was `ok=204 changed=95 unreachable=0 failed=0 skipped=184`. The successful Worker retry was `ok=150 changed=29 unreachable=0 failed=0 skipped=236`; its Admin and Worker reconciliation steps had `failed=0 unreachable=0`. The Portal recap was `ok=196 changed=78 unreachable=0 failed=0 skipped=190`; peer reconciliation for Admin, Worker, and Portal had `failed=0 unreachable=0`.

The first Worker install attempt was stopped when guest available RAM fell below the 256 MiB safety floor. The VM was not killed. The install was rerun successfully after raising that existing VM's configured RAM to 1.25 GiB. No product or RPM changed between attempts. Details remain in `worker-install-wrapper.log` and `worker-install-attempt-2.log`.

SELinux was `Enforcing` on all nodes. The required role services were active; no failed Admiral or Podman system/user units remained. Admiral reported `worker-001` and `portal-001` active, healthy, and available for provisioning. The Portal was separate from Admin. WireGuard peer registration and authenticated Portal-to-Admiral API calls succeeded.

## Harbor customer flow and workload

Harbor was reached directly at `https://10.99.0.100:5001` using `/etc/admiral/tls/ca.pem`. The certificate SAN contains the Portal WireGuard IP. `curl` returned `HTTP=200 TLS_verify=0`; verification was enabled and no insecure TLS option was used. The Portal's `HARBOR_EXTERNAL_URL` is a lab placeholder and no public Caddy site route was configured.

The real customer flow passed:

1. Customer registration created a pending account.
2. Login was rejected while the account was pending.
3. Harbor Admin approved the customer.
4. The test app was synced and published in the Harbor catalog.
5. The approved customer logged in and deployed the free tier.

Admiral recorded successful provisioning operation `op_4dc9ff9a3e4f3f5a` and assigned instance `inst_2c5534fa54019082` to `worker-001`. The Worker ran the `app` and PostgreSQL `db` containers rootless under `admiral-apps` in a Podman pod. PostgreSQL accepted connections. A brief initial health poll ran before the PostgreSQL container was ready; the instance then reached `running`, `healthy`, and `available` automatically, and the provisioning operation completed successfully. The observed transition is recorded in [`customer-flow/health-transition.json`](customer-flow/health-transition.json).

The workload endpoint at `http://10.99.0.2:40000/` returned HTTP 200 from the Admin over WireGuard. The Whoami response identified the deployed instance. A PostgreSQL marker was written into the instance database, the instance was restarted through Admiral, and the marker was read back unchanged. Both restart operations succeeded. PostgreSQL remained ready and the endpoint again returned HTTP 200 after restart.

Deprovision operation `op_42041d21ee756b79` succeeded. Admiral's final state was `technical_status=deprovisioned`, `health_status=stopped`, `effective_availability=unavailable`, and `node_id=worker-001`. The Worker check found zero containers, pods, volumes, secrets, user units, Quadlets, instance files, or failed Admiral units attributable to this instance. The final node inventory still reported both Worker and Portal healthy and available.

The customer path used Harbor for registration, approval, catalog access, and deployment. Deprovision was executed through the supported operator `admiralctl instances deprovision` command; Harbor's customer UI offers cancellation and normal lifecycle actions, but no immediate customer deprovision action for this free fixture.

## Scope and Caddy

The Admin Caddy service was active, but its Caddyfile had no site route because the lab has no domain pointed at the server. Per the user's direction, this domain-dependent Caddy routing check was not required and was not claimed as tested. Harbor TLS was still validated directly on the Portal's WireGuard IP, and the customer/deploy flow exercised Portal-to-Admiral communication over the authenticated WireGuard/TLS API path.

## Resource and cleanup record

Resource floors used by the validation were 2 GiB available RAM and 30 GiB available disk on the host, and 256 MiB RAM and 1.5 GiB disk in each guest. The lowest sampled host memory while the workload was starting was 2,212,909,056 bytes (about 2.06 GiB); the workload was then kept to the fixture's 512 MiB tier. Sampled worker memory remained above 660 MiB and guest disk remained above 6.7 GiB. No safety floor was crossed, no VM was killed, and no host disk cleanup was needed.

At the final check, the host had 2,323,240 KiB available RAM and 38,493,818,880 bytes available disk. All three validation VMs remained running; the unrelated existing `rc6e5r18-ipv6-r255-worker2` remained shut off.

## Evidence

- Admin, Worker, and Portal installer logs: this directory's `admin-install.log`, `worker-install-attempt-2.log`, and `portal-install.log`.
- Customer flow, TLS, and lifecycle records: [`customer-flow/`](customer-flow/).
- Final installed package, SELinux, service, failed-unit, and guest-resource checks: `customer-flow/admin-final-check.txt`, `customer-flow/worker-final-check.txt`, and `customer-flow/portal-final-check.txt`.
- The customer-flow harness and cleanup checks are validation-only files; no installed product was modified.

## Release interpretation

The CentOS Stream 10 Multi-Node cell passes within the scope above. The Caddy hostname route was waived by the user because no domain is configured. Cacao Accounting passing is also non-mandatory. The overall R21 matrix is now **2/6**; Rocky Linux 10 and Fedora Rawhide cells remain pending. R21 is **not Gold**, and issue #305 remains open for ERPNext and NOW-LMS follow-up.
