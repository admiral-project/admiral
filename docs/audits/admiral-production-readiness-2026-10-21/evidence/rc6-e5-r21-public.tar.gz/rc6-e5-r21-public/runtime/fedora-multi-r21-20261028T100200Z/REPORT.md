# Fedora Rawhide x86_64 Multi-Node — R21

Date: 2026-10-28 UTC  
Candidate: RC6 E5 R21, Fedora-native RPM Release 21 (`5:0.0.1rc6-21.fc46`)  
Result: **PASS** for the Fedora Rawhide Multi-Node release-matrix cell.

No Admiral product source or RPM changed during this validation. `PRODUCT_CHANGED=NO` and `CANDIDATE_INVALIDATED=NO`. The three existing Fedora validation VMs were reused; no VM was created or deleted. Worker and Portal were shut down gracefully after the workload had been deprovisioned. Admin remains running.

## Topology and package identity

| Role | Existing VM | Lab IPv4 | WireGuard IP | OS |
|---|---|---|---|---|
| Admin | `rc6e5r18-ipv6-admin` | `192.168.122.20` | `10.99.0.1` | Fedora Rawhide x86_64 |
| Worker | `rc6e5r18-ipv6-worker` | `192.168.122.21` | `10.99.0.2` | Fedora Rawhide x86_64 |
| Portal | `rc6e5r18-ipv6-portal` | `192.168.122.22` | `10.99.0.100` | Fedora Rawhide x86_64 |

All installed Admiral packages were the native Fedora `.fc46` build for Epoch 5, Version `0.0.1rc6`, Release 21. Admin had all six candidate RPMs; Worker had `admiral-common` and `admiral-fleet`; Portal had `admiral-common` and `admiral-harbor`. The exact NEVRAs and SHA-256 values are in [`fedora-rpm-manifest.tsv`](fedora-rpm-manifest.tsv), and the package checksums were verified as recorded in [`fedora-repo-checksums-verified.txt`](fedora-repo-checksums-verified.txt). No EL10 RPM was installed on Fedora.

The existing lab uses the management IPv4 network plus the WireGuard IPv4 overlay. Static ULA IPv6 addresses were assigned to the lab's third NICs so NetworkManager could complete `wait-online`; that NIC has no default route. This run does not claim validation of public IPv6-only node reachability.

## Secure setup and node health

The Admin, Worker, and Portal roles installed successfully with the secure-mode candidate packages. All three nodes registered and were observed active and healthy. The early Portal setup ran while Worker was shut down to stay within the host RAM floor, so initial peer inventory omitted the Worker-to-Portal edge. With all three nodes active, the packaged `admiral-wireguard-peer-inventory` and `wireguard-peers.yml` reconciliation completed without failed hosts and restored the expected peer and firewall rule. See [`wireguard-peer-reconciliation.log`](wireguard-peer-reconciliation.log), [`worker-wireguard-peers.txt`](worker-wireguard-peers.txt), and [`portal-wireguard-peers-after-sync.txt`](portal-wireguard-peers-after-sync.txt).

Final checks recorded SELinux Enforcing, required Admin/Worker/Portal services active, no failed system units, rootless Podman on Worker, and no kernel OOM records. The final checks are [`admin-final-check.txt`](admin-final-check.txt), [`worker-final-check.txt`](worker-final-check.txt), and [`portal-final-check.txt`](portal-final-check.txt). The independent Worker-to-Portal Harbor request returned HTTP 200 over WireGuard with TLS verification result 0; see [`worker-to-portal-harbor-tls.txt`](worker-to-portal-harbor-tls.txt). No public Caddy hostname route was tested because the lab has no domain pointing to it, consistent with the agreed validation scope.

## Portal customer flow and workload lifecycle

The existing `e2e-portal-free` fixture completed the independent Portal flow: signup remained pending, login was rejected while pending, Admin approval succeeded, the catalog was published, and the customer deployed the free tier. The complete result is in [`customer-flow.log`](customer-flow.log).

The deployed instance `inst_1c348cac08316217` ran a rootless Podman pod on `worker-001` with the `whoami` app and PostgreSQL. Its HTTP endpoint returned 200 directly over WireGuard before and after a forced restart. A database marker written before restart was read unchanged afterward, demonstrating PostgreSQL volume persistence. See [`http-before-restart.txt`](http-before-restart.txt), [`http-after-restart.txt`](http-after-restart.txt), [`postgres-marker-before-restart.txt`](postgres-marker-before-restart.txt), [`postgres-marker-after-restart.txt`](postgres-marker-after-restart.txt), and [`restart-operation.json`](restart-operation.json).

The supported deprovision operation succeeded. The final instance state was `deprovisioned`; the Worker had zero matching containers, pods, volumes, secrets, user units, Quadlets, instance files, or failed Admiral units. See [`deprovision-operation.json`](deprovision-operation.json), [`final-instance.json`](final-instance.json), and [`post-deprovision-check.log`](post-deprovision-check.log).

## Resource monitoring and VM cleanup

The resource monitor recorded 118 samples from 10:04:56 to 10:41:25 UTC with zero threshold alerts. Configured safety floors were host available RAM ≥2 GiB and free disk ≥30 GiB, and guest available RAM ≥256 MiB and free disk ≥1.5 GiB.

| System | Samples with guest data | Minimum available RAM | Minimum free disk |
|---|---:|---:|---:|
| Host | 118 | 2,220.9 MiB | 46.22 GiB |
| Admin | 118 | 608.2 MiB | 8.31 GiB |
| Worker | 65 | 550.1 MiB | 8.05 GiB |
| Portal | 73 | 448.5 MiB | 8.34 GiB |

Worker and Portal were stopped with `virsh shutdown` and both reached `shut off`; neither was killed. Their shutdown records are [`worker-graceful-shutdown.txt`](worker-graceful-shutdown.txt) and [`portal-graceful-shutdown.txt`](portal-graceful-shutdown.txt). Afterward the host had 4.5 GiB available RAM and 47 GiB available disk. The raw samples are in [`resource-monitor.jsonl`](resource-monitor.jsonl); its SHA-256 is covered by this directory's `SHA256SUMS`.

## Release interpretation

Fedora Rawhide x86_64 Multi-Node passes on the exact R21 candidate. Together with the five previously passing cells, the required Rocky Linux 10, CentOS Stream 10, and Fedora Rawhide Single-Node and Multi-Node matrix is now **6/6**. The complete current status is in [`../../R21-VALIDATION-STATUS.md`](../../R21-VALIDATION-STATUS.md).

This cell does not make R21 Gold. GitHub issues remain open, including #305; the #305 examples ERPNext and NOW-LMS remain unresolved. Cacao Accounting passing is not mandatory. Per the release rule, no release is Gold while issues remain open.
