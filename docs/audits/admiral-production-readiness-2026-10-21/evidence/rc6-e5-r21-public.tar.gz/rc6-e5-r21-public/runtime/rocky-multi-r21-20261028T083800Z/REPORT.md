# Rocky Linux 10 x86_64 Multi-Node — R21

Date: 2026-10-28 UTC  
Candidate: RC6 E5 R21, EL10 RPM Release 21  
Result: **PASS** for the Multi-Node runtime scope.

No Admiral product source or RPM changed during this cell. `CANDIDATE_INVALIDATED = NO`. The three existing validation domains were reused; no VM was created, deleted, or killed. Their previous overlays were preserved.

## Topology and candidate packages

| Role | Existing VM | WireGuard IP | Final RAM | R21 packages |
|---|---|---|---:|---|
| Admin | `rc6e5r18-ipv6-admin` | `10.99.0.1` | 1.25 GiB | `admiral-common`, `admirald`, `admiralctl`, `admiral-flagship` |
| Worker | `rc6e5r18-ipv6-worker` | `10.99.0.2` | 1 GiB | `admiral-common`, `admiral-fleet` |
| Portal | `rc6e5r18-ipv6-portal` | `10.99.0.100` | 1.25 GiB | `admiral-common`, `admiral-harbor` |

Every installed package reported `5:0.0.1rc6-21.el10`. Final package, service, SELinux, and failed-unit checks are in `customer-flow/{admin,worker,portal}-final-check.txt`. SELinux was enforcing, each required service was active, and no Admiral, Harbor, Podman, WireGuard, Caddy, or PostgreSQL units were failed. Admin reported both spokes active, healthy, and available with Rocky Linux 10.2.

Install recaps: Admin `ok=205 changed=95 unreachable=0 failed=0`; Worker `ok=153 changed=52 unreachable=0 failed=0`; Portal `ok=197 changed=78 unreachable=0 failed=0`. Secure peer reconciliation and temporary bootstrap-key revocation passed on both spokes. Complete logs are `admin-install.log`, `worker-install.log`, and `portal-install.log`.

The memory sizing was adjusted on these existing domains to keep the host above its 2 GiB floor with all three guests running. `memory-sizing.txt` and the three `*-mem-adjusted.xml` files record the configuration. No guest was allowed below the 256 MiB available-RAM floor.

## Harbor, workload, and lifecycle

The Portal was reached directly over WireGuard at `https://10.99.0.100:5001`; `customer-flow/harbor-internal-tls.txt` records `HTTP=200 TLS_verify=0`. The installed Admiral CA validated the certificate. No public domain points at this lab, so the domain-dependent Caddy hostname route was not tested, per the user's direction.

The first customer-flow attempt registered and approved a test customer but did not find the app in Harbor's catalog. During initial setup, the catalog timer started at 09:14:09 UTC and the installer restarted Harbor at 09:14:19, interrupting that sync. The next timer initially skipped the still-marked in-progress sync. At 09:19:25 it marked the abandoned run failed, synchronized `e2e-portal-free`, and completed successfully. The interrupted attempt and recovery evidence are retained in `customer-flow/customer-flow-attempt-1.log`, `portal-catalog-debug.log`, and `catalog-sync-timer.log`; no product or RPM changed.

After catalog recovery, the independent Portal customer flow passed:

1. Registration created a pending customer, and pending login was rejected.
2. Harbor Admin approved the customer, synchronized and published `e2e-portal-free`, and the customer deployed the free tier.
3. Admiral provisioned `inst_8b9068d7c07ca16c` on `worker-001`. The rootless Podman pod ran the `whoami` app and PostgreSQL. The first control-plane observation preceded DB readiness and reported the DB container unavailable; the runtime check then saw PostgreSQL accepting connections, and the next control-plane observation reached `running/healthy/available`. The transition is recorded in `customer-flow/health-transition.txt`.
4. The workload endpoint returned HTTP 200 over WireGuard before and after restart. A PostgreSQL marker was written before restart and read unchanged afterward.
5. The supported `admiralctl instances deprovision` operation succeeded. Final instance state was `deprovisioned/stopped/unavailable`; the Worker had zero matching containers, pods, volumes, secrets, user units, Quadlets, files, or failed Admiral units.

See `customer-flow/customer-flow.log`, `instances-after-provision.json`, `http-{before,after}-restart.txt`, `postgres-marker-{before,after}-restart.txt`, the restart/deprovision operation records, `final-instance.json`, and `post-deprovision-check.log`.

## Resource and cleanup record

The monitored floors were host available RAM ≥2 GiB and disk ≥30 GiB; each guest available RAM ≥256 MiB and disk ≥1.5 GiB. Across setup and workload:

- Host minimum: 2,269,836 KiB available RAM (about 2.16 GiB) and 52,490,776,576 bytes available disk (about 48.9 GiB).
- Admin minimum: 592,844 KiB RAM and 7,020,675,072 bytes disk available.
- Worker minimum: 394,180 KiB RAM and 6,559,993,856 bytes disk available.
- Portal minimum: 415,384 KiB RAM and 7,075,741,696 bytes disk available.
- All three resource monitors recorded zero threshold alerts. The kernel OOM check found no OOM or killed-process records. No VM was killed and no disk cleanup was needed.

Raw samples are in `admin-resource-monitor.jsonl`, `worker-resource-monitor.jsonl`, and `portal-resource-monitor.jsonl`; `customer-flow/resource-summary.txt` summarizes the minima.

## Release interpretation

Rocky Linux 10 Multi-Node passes on the exact R21 candidate. The catalog-sync interruption and automatic recovery are documented above; the end-to-end customer flow passed after synchronization completed. Cacao Accounting passing is not mandatory. This cell does not make R21 Gold; the full six-cell matrix and open-issue gate remain separate release requirements.
