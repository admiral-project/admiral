R21 historical candidate evidence archive.
This archive contains R21 candidate reports, all six cell result artifacts, build/signature outputs, and workload-validation evidence.
Scripts and YAML/diff inputs with extensions .sh, .py, .yaml, .yml, and .diff were excluded because test fixtures can contain generated test credentials or local harness details. Their paths and SHA-256 digests are listed in EXCLUDED-TEST-INPUTS.tsv.
PUBLIC-SHA256SUMS covers every file in this publication bundle except itself. The original per-run manifests are preserved as historical records and may mention excluded test inputs.
This is historical R21 evidence only. A later Fleet product change means R21 does not pass a subsequent candidate.
